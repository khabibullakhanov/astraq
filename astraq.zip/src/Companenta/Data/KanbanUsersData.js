export const KanbanUsersData = async () => {
    return [
        {
            id: 1,
            name: "Wireframing",
            work: "Design Team",
            team: "3",
            skripka: "7",
            message: "5",
            progressLength: "97%",
            color: "#5149E4"
        },
        {
            id: 2,
            name: "High Fidelity",
            work: "Design Team",
            team: "2",
            skripka: "6",
            message: "9",
            progressLength: "23%",
            color: "#FFB9CD"
        },
        {
            id: 3,
            name: "Nadila Adja",
            work: "Developer Team",
            team: "5",
            skripka: "2",
            message: "8",
            progressLength: "84%",
            color: "#B9EEFF"
        },
        {
            id: 4,
            name: "Jordan Nico",
            work: "Developer Team",
            team: "4",
            skripka: "7",
            message: "1",
            progressLength: "49%",
            color: "#F4E131"
        },
        {
            id: 5,
            name: "Karen Hope",
            work: "Design Team",
            team: "2",
            skripka: "9",
            message: "3",
            progressLength: "75%",
            color: "#FF5B5B"
        },
        {
            id: 6,
            name: "Christian Jornald",
            work: "Design Team",
            team: "5",
            skripka: "2",
            message: "9",
            progressLength: "38%",
            color: "#00A389"
        },
        {
            id: 7,
            name: "Rachel Happy",
            work: "Developer Team",
            team: "2",
            skripka: "7",
            message: "7",
            progressLength: "57%",
            color: "#5149E4"
        },
        {
            id: 8,
            name: "Vita Delong",
            work: "Developer Team",
            team: "7",
            skripka: "2",
            message: "5",
            progressLength: "27%",
            color: "#0A0603"
        },
        {
            id: 9,
            name: "Cahaya Hikari",
            work: "Design Team",
            team: "1",
            skripka: "8",
            message: "3",
            progressLength: "67%",
            color: "#A18594"
        },
        {
            id: 10,
            name: "Angelina Crispy",
            work: "Developer Team",
            team: "2",
            skripka: "5",
            message: "9",
            progressLength: "82%",
            color: "#F4F4F4"
        },
        {
            id: 11,
            name: "Yuki Suki",
            work: "Design Team",
            team: "9",
            skripka: "3",
            message: "7",
            progressLength: "43%",
            color: "#2271B3"
        },
        {
            id: 12,
            name: "Jane Badriah",
            work: "Developer Team",
            team: "1",
            skripka: "3",
            message: "7",
            progressLength: "92%",
            color: "#49678D"
        },
    ]
}