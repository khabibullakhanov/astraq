export const DashboardRightUsers = async () => {
    return [
    {
        id: 1,
        name: "Tony Soap",
        message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
    },
    {
        id: 2,
        name: "Samantha William",
        message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
    },
    {
        id: 3,
        name: "Nadila Adja",
        message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
    },
    {
        id: 4,
        name: "Jordan Nico",
        message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
    },
]
}