export const DashboardRightUsers = async () => {
    return [
        {
            id: 1,
            name: "Tony Soap",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 2,
            name: "Samantha William",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 3,
            name: "Nadila Adja",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 4,
            name: "Jordan Nico",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 5,
            name: "Tony Soap",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 6,
            name: "Samantha William",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 7,
            name: "Nadila Adja",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 8,
            name: "Jordan Nico",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 9,
            name: "Tony Soap",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 10,
            name: "Samantha William",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 11,
            name: "Nadila Adja",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        {
            id: 12,
            name: "Jordan Nico",
            message: "Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        },
        // {
        //     id: 13,
        //     name: "Tony Soap",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 14,
        //     name: "Samantha William",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 15,
        //     name: "Nadila Adja",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 16,
        //     name: "Jordan Nico",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 17,
        //     name: "Tony Soap",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 18,
        //     name: "Samantha William",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 19,
        //     name: "Nadila Adja",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 20,
        //     name: "Jordan Nico",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 21,
        //     name: "Tony Soap",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 22,
        //     name: "Samantha William",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 23,
        //     name: "Nadila Adja",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
        // {
        //     id: 24,
        //     name: "Jordan Nico",
        //     message:"Sed eligendi facere repellendus. Ipsam ipsam incidunt minima harum tenetur. Ab sit asperiores architecto repudiandae."
        // },
    ]
}